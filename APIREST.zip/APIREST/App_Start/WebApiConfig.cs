﻿//using Microsoft.AspNet.WebApi.Extensions.Compression.Server;
using APIREST.Controllers;
using Microsoft.AspNet.WebApi.Extensions.Compression.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Extensions.Compression.Core.Compressors;
//using System.Net.Http.Extensions.Compression.Core.Compressors;
using System.Web.Http;
//using Microsoft.AspNet.WebApi.Extensions.Compression.;



namespace APIREST
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Configuración y servicios de API web

            // Rutas de API web
            config.MapHttpAttributeRoutes();
            config.MessageHandlers.Add(new TokenValidationHandler()); // manejador   validar el token 

            config.Routes.MapHttpRoute(
                name: "DefaultApi",

                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
             //configurar como el primer manejador de mensajes -- para que comprima y descomprima el Ws
             GlobalConfiguration.Configuration.MessageHandlers.Insert(0,new ServerCompressionHandler(0,new GZipCompressor(), new DeflateCompressor()));
             config.Formatters.Remove(config.Formatters.XmlFormatter);
             config.Formatters.JsonFormatter.SupportedMediaTypes.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        }
    }
}
