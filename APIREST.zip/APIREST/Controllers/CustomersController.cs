﻿using APIREST.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace APIREST.Controllers
{

        /// <summary>
        /// customer controller class for testing security token
        /// </summary>
        [Authorize]
        [RoutePrefix("api/customers")]
        public class CustomersController : ApiController
        {
            [HttpGet]
            public IHttpActionResult GetId(int id)
            {
                var customerFake = "customer-fake";
                return Ok(customerFake);
            }

            [HttpGet]
            public IHttpActionResult GetAll()
            {
                var customersFake = new string[] { "customer-1", "customer-2", "customer-3" };
            IEnumerable<ModelCliente> cl = new List<ModelCliente> {

               new ModelCliente
               {
                   id = 1 ,
                   Nombre = "Davivienda",
                   Direccion = "Bogota"
               },
               new ModelCliente
               {
                   id = 2,
                   Nombre = "Banco Agrario",
                   Direccion = "Sincelejo"
               },

               new ModelCliente
               {
                   id = 3,
                   Nombre = "Vilma Ro",
                   Direccion = "Cra 16 Nro 65 73"
               }
            };
            return Ok(cl);
            // return Ok(customersFake);
        }
        }
    
}
