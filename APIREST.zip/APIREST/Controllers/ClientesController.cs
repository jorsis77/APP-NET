﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using APIREST.Models;

namespace APIREST.Controllers
{
    public class ClientesController : ApiController
    {
        // GET: api/Clientes
        [Authorize]
        public IEnumerable<Models.ModelCliente> Get()
        {
            IEnumerable<ModelCliente> cl = new List<ModelCliente> {

               new ModelCliente
               {
                   id = 1 ,
                   Nombre = "Davivienda",
                   Direccion = "Bogota"
               },
               new ModelCliente
               {
                   id = 2,
                   Nombre = "Banco Agrario",
                   Direccion = "Sincelejo"
               },

               new ModelCliente
               {
                   id = 3,
                   Nombre = "Vilma Ro",
                   Direccion = "Cra 16 Nro 65 73"
               },

               new ModelCliente
               {
                   id = 1 ,
                   Nombre = "Davivienda",
                   Direccion = "Bogota"
               },
               new ModelCliente
               {
                   id = 2,
                   Nombre = "Banco Agrario",
                   Direccion = "Sincelejo"
               },

               new ModelCliente
               {
                   id = 3,
                   Nombre = "Vilma Ro",
                   Direccion = "Cra 16 Nro 65 73"
               },

               new ModelCliente
               {
                   id = 1 ,
                   Nombre = "Davivienda",
                   Direccion = "Bogota"
               },
               new ModelCliente
               {
                   id = 2,
                   Nombre = "Banco Agrario",
                   Direccion = "Sincelejo"
               },

               new ModelCliente
               {
                   id = 3,
                   Nombre = "Vilma Ro",
                   Direccion = "Cra 16 Nro 65 73"
               },

               new ModelCliente
               {
                   id = 1 ,
                   Nombre = "Davivienda",
                   Direccion = "Bogota"
               },
               new ModelCliente
               {
                   id = 2,
                   Nombre = "Banco Agrario",
                   Direccion = "Sincelejo"
               },

               new ModelCliente
               {
                   id = 3,
                   Nombre = "Vilma Ro",
                   Direccion = "Cra 16 Nro 65 73"
               },

               new ModelCliente
               {
                   id = 1 ,
                   Nombre = "Davivienda",
                   Direccion = "Bogota"
               },
               new ModelCliente
               {
                   id = 2,
                   Nombre = "Banco Agrario",
                   Direccion = "Sincelejo"
               },

               new ModelCliente
               {
                   id = 3,
                   Nombre = "Vilma Ro",
                   Direccion = "Cra 16 Nro 65 73"
               },

               new ModelCliente
               {
                   id = 1 ,
                   Nombre = "Davivienda",
                   Direccion = "Bogota"
               },
               new ModelCliente
               {
                   id = 2,
                   Nombre = "Banco Agrario",
                   Direccion = "Sincelejo"
               },

               new ModelCliente
               {
                   id = 3,
                   Nombre = "Vilma Ro",
                   Direccion = "Cra 16 Nro 65 73"
               }

           };

            return cl; //new string[] { "value1", "value2" };
        }

        // GET: api/Clientes/5
        public ModelCliente Get(int id)
        {
            ModelCliente CL = new ModelCliente();

            switch (id)
            {
                case 1:

                    CL = new ModelCliente
                    {
                        id = 1,
                        Nombre = "Jose Rene Ramirez",
                        Direccion = "Bogota"
                    };
                    break;


                case 2:
                    CL = new ModelCliente
                    {
                        id = 2,
                        Nombre = "Carlos Rene Ramirez",
                        Direccion = "Sincelejo"
                    };
                    break;
                case 3:
                    CL = new ModelCliente
                    {
                        id = 3,
                        Nombre = "Vilma Ro",
                        Direccion = "Cra 16 Nro 65 73"
                    };
                    break;
                    ;
                default:
                    break;
            }
            

            return CL;
        }

        // POST: api/Clientes
        //public string Post(ModelCliente value)
        public string Post(ModelCliente value)
        {
            return "Todo bien POst" ;
        }

        // PUT: api/Clientes/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Clientes/5
        public string Delete(int id)
        {
            return "Todo bien POst";
        }
    }
}
